export default class Controller{
    constructor(game, view, recorder){
        this.recorder = recorder;
        this.game = game;
        this.view = view;
        this.speed = 1000;
        this.canvas = document.getElementById('tetris');
        this.contex = this.canvas.getContext('2d');
        this.intervalid = setInterval(() => {
            this.update();
        }, this.speed > 0 ? this.boostSpeed() : 100);

        document.addEventListener('keydown', this.handleKeyDown.bind(this));

    }
    handleKeyDown(event){
        switch (event.keyCode) {
            case 13:
                if(this.game.getState().isGameOver){
                    window.location.reload();
                }
            case 37:
                this.game.moveLeft();
                this.view.viewRender(game.getState());
                break;
            case 38:
                this.game.rotation();
                this.view.viewRender(game.getState());
                break;
            case 39:
                this.game.moveRight();
                this.view.viewRender(game.getState());
                break;
            case 40:
                const tmp_lines = this.game.lines;
                this.game.moveDown();
                this.checkLvl(tmp_lines);
                
                console.log(this.speed);
                this.view.viewRender(game.getState());
                break;  
            default:
                break;
        }
    }
    boostSpeed(){
        this.speed = 1000 - this.game.getState().level * 200;
        if(this.speed == 0){
            return 200;
        }
        return this.speed;
    }
    update(){
        this.game.moveDown();
        this.view.viewRender(game.getState());
        if(this.game.getState().isGameOver){
            window.location.href = 'end.html';   
        }
    }
    checkLvl(tmp_lines){
        if(this.game.lines != tmp_lines){
            clearInterval(this.intervalid);
            this.intervalid = setInterval(() => {
                this.update();
            }, this.speed > 0 ? this.boostSpeed() : 200);
        }
    }
}