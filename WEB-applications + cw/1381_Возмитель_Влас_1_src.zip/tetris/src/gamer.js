export default class Game{
    static points = {
        '1': 40,
        '2': 100,
        '3': 300,
        '4': 1200
    };
    lines = 0;
    
    constructor(recorder){
        this.recorder = recorder;
        this.topOut = false;
        this.score = 0;
        this.playfield = this.createPlayField();
        this.activePiece = this.createPiece();
        this.nextPiece = this.createPiece();
    }
    get level(){
        return Math.floor(this.lines / 3);
    }

    moveLeft(){
        this.activePiece.x -= 1;

        if(this.IsBarrier()){
            this.activePiece.x += 1;
        }
    }

    moveRight(){
        this.activePiece.x += 1;

        if(this.IsBarrier()){
            this.activePiece.x -= 1;
        }
    }

    moveDown(){
        if(this.topOut) return;
        this.activePiece.y += 1;

        if(this.IsBarrier()){
            this.activePiece.y -= 1;
            this.lockPiece();
            const clearedlines = this.clearlines();
            this.updateScore(clearedlines);
            this.updatePieces(); 
        }

        if(this.IsBarrier()){
            this.topOut = true;
            this.recorder.writeResults();
        }
    }

    rotation(){
        this.rotateBlocks();

        if(this.IsBarrier()){
            this.rotateBlocks(false);
        }
    }

    rotateBlocks(clockwise = true){
        const blocks = this.activePiece.blocks;
        const length = blocks.length;
        const x = Math.floor(length / 2);
        const y = length - 1;

        for (let i = 0; i < x; i++) {
            for (let j = i; j < y - i; j++) {
                const cur = blocks[i][j];
                
                if(clockwise){
                    blocks[i][j] = blocks[y - j][i];
                    blocks[y - j][i] = blocks[y - i][y - j];
                    blocks[y - i][y - j] = blocks[j][y - i];
                    blocks[j][y - i] = cur;
                } else {
                    blocks[i][j] = blocks[j][y - i];
                    blocks[j][y - i] = blocks[y - i][y - j];
                    blocks[y - i][y - j] = blocks[y - j][i];
                    blocks[y - j][i] = cur;
                }
            }
        }
    }

    IsBarrier(){
        const {y: pieceY, x: pieceX, blocks} = this.activePiece;
        const field = this.playfield;

        for (let y = 0; y < blocks.length; y++) {
            for (let x = 0; x < blocks[y].length; x++) {
                if(blocks[y][x] 
                    && (field[pieceY + y] === undefined || field[pieceY + y][pieceX + x] === undefined 
                    || this.playfield[pieceY + y][pieceX + x])){
                    return true;
                }
            }
        }

        return false;
    }

    lockPiece(){
        const field = this.playfield;
        const {y: pieceY, x: pieceX, blocks} = this.activePiece;

        for (let y = 0; y < blocks.length; y++) {
            for (let x = 0; x < blocks[y].length; x++) {
                if(blocks[y][x]){
                    field[pieceY + y][pieceX + x] = blocks[y][x];
                }
            }
        }
    }

    createPlayField(){
        const playfield = [];

        for (let y = 0; y < 20; y++) {
            playfield[y] = [];

            for (let x = 0; x < 10; x++) {
                playfield[y][x] = 0;
            }
        }
        return playfield;
    }

    createPiece(){
        const ind = Math.floor(Math.random() * 7);
        const piece = {};
        switch (ind) {
            case 0:
                piece.blocks = [
                    [0,0,0,0],
                    [1,1,1,1],
                    [0,0,0,0],
                    [0,0,0,0]
                ];
                break;
            case 1:
                piece.blocks = [
                    [0,0,0],
                    [2,2,2],
                    [0,0,2]
                ];
                break;
            case 2:
                piece.blocks = [
                    [0,0,0],
                    [3,3,3],
                    [3,0,0]
                ];
                break;
            case 3:
                piece.blocks = [
                    [0,0,0,0],
                    [0,4,4,0],
                    [0,4,4,0],
                    [0,0,0,0]
                ];
                break;
            case 4:
                piece.blocks = [
                    [0,0,0],
                    [0,5,5],
                    [5,5,0]
                ];
                break;
            case 5:
                piece.blocks = [
                    [0,0,0],
                    [6,6,6],
                    [0,6,0]
                ];
                break;
            case 6:
                piece.blocks = [
                    [0,0,0],
                    [7,7,0],
                    [0,7,7]
                ];
                break;
            default:
                break;
        }
        piece.x = Math.floor((10 - piece.blocks[0].length) / 2);
        piece.y = 0;
        return piece
    }

    getState(){
        const playfield = this.createPlayField();
        const { y: pieceY, x: pieceX, blocks} = this.activePiece;

        for (let y = 0; y < playfield.length; y++) {
            playfield[y] = [];

            for (let x = 0; x < this.playfield[y].length; x++) {
                playfield[y][x] = this.playfield[y][x];
            }
        }

        for (let y = 0; y < blocks.length; y++) {
            for (let x = 0; x < blocks[y].length; x++) {
                if(blocks[y][x]){
                    playfield[pieceY + y][pieceX + x] = blocks[y][x];
                }
            }
        }
        return {
            score: this.score,
            level: this.level,
            lines: this.lines,
            nextPiece: this.nextPiece,
            playfield,
            isGameOver: this.topOut
        };
    }
    updatePieces(){
        this.activePiece = this.nextPiece;
        this.nextPiece = this.createPiece();
    }

    clearlines(){
        const rows = 20;
        const colums = 10;
        const lines = [];
        
        for (let y = rows - 1; y >= 0; y--) {
            let numberOfBlocks = 0
            
            for (let x = 0; x < colums; x++) {
                if(this.playfield[y][x]){
                    numberOfBlocks += 1;
                }
            }
            if (numberOfBlocks === 0){
                break;
            } else if (numberOfBlocks < colums) {
                continue;
            } else if (numberOfBlocks === colums){
                lines.unshift(y);
            }
        }
        for (let index of lines){
            this.playfield.splice(index, 1);
            this.playfield.unshift(new Array(colums).fill(0));
        }
        return lines.length;
    }

    updateScore(clearedlines){
        if(clearedlines > 0){
            this.score += Game.points[clearedlines] * (this.level + 1);
            this.lines += clearedlines;

            this.recorder.record.score += this.score;
            this.recorder.record.lvl = this.level;
            document.getElementById("record").innerText = "Рекорд: " + this.recorder.record.score;
            document.getElementById("lvl").innerText = "Уровень: " + this.recorder.record.lvl;
        }
    }
}