import '../style.css' assert { type: 'css' };
import Game from './gamer.js';
import View from './viewer.js';
import Controller from './controller.js';
import Score from './recorder.js'

const root = document.querySelector('#app');
let recorder = new Score(localStorage['tetris.username'], 0, 0);


const game = new Game(recorder);
const view = new View(root, 320, 640, 20, 10);
const controller = new Controller(game, view, recorder);

window.game = game;
window.view = view;
window.controller = controller;

view.viewRender(game.getState());