export default class Score {
    game_over = false;
    record = {
        place: 0,
        score: 0,
        name: '',
    }
    constructor(name, score, place) {
        this.record.name = name;
        if (!this.record.name){
            this.record.name = 'player';
        }
        this.record.score = score;
        this.record.place = place;
        console.log(this.record.name);
    }
    writeResults() {
        let score_table = JSON.parse(localStorage.getItem('таблицаРекордов')) || [];
        score_table.push(this.record);
        score_table.sort((a, b) => b.score - a.score);
        score_table.forEach((record, index) => {
            record.place = index + 1;
        });
        localStorage.setItem('таблицаРекордов', JSON.stringify(score_table));
    }
}