export default class View{
    constructor(elements, width, height, rows, columns){
        this.elements = elements;
        this.height = height;
        this.width = width;
        
        this.canvas = document.getElementById('tetris');
        this.context = this.canvas.getContext('2d');
        this.elements.appendChild(this.canvas);

        this.BlockWidth = this.width / columns;
        this.blockHeight = this.height / rows;
        this.NextBlock = document.getElementById("state");
        this.NextBlockContext = this.NextBlock.getContext('2d');
        this.NextBloclWidth = this.NextBlock.width / columns;
        this.NextBloclHeight = this.NextBlock.height / rows;

        this.elements.appendChild(this.NextBlock);
    }
    static colors = {
        '1': '#676767',
        '2': '#9A9A9A',
        '3': '#5A7E96',
        '4': '#295436',
        '5': '#515C4C',
        '6': '#7FB3DA',
        '7': '#E4F1FA'
    };
    viewRender(state){
        this.context.clearRect(0, 0, this.width, this.height);
        this.NextBlockContext.clearRect(0, 0, this.width, this.height);

        this.viewPLayfiled(state);
        this.viewNextBlock(state);
    }
    viewPLayfiled({ playfield }){
        for (let y = 0; y < playfield.length; y++) {
            const line = playfield[y];

            for (let x = 0; x < line.length; x++) {
                const block = line[x];

                if(block){
                    this.viewBlock(x * this.BlockWidth, y * this.blockHeight, this.BlockWidth, this.blockHeight, View.colors[block])
                }
            }
        }
    }
    viewBlock(x, y, width, height, color){
        this.context.fillStyle = color;
        this.context.strokeStyle = 'black';
        this.context.lineWidth = 2;

        this.context.fillRect(x, y, width, height);
        this.context.strokeRect(x, y, width, height);
    }

    viewNextBlock({ nextPiece }){
        this.NextBlockContext.textAlign = 'start';
        this.NextBlockContext.textBaseline = 'top';
        this.NextBlockContext.fillStyle = 'white';
        this.NextBlockContext.font = 'bold 16px sans-serif';

        for(let y = 0; y < nextPiece.blocks.length; y++){
            for (let x = 0; x < nextPiece.blocks[y].length; x++) {
                const block = nextPiece.blocks[y][x];
                if(block){
                    this.NextBlockContext.fillStyle = View.colors[block];
                    this.NextBlockContext.strokeStyle = 'black';
                    this.NextBlockContext.lineWidth = 2;
                    this.NextBlockContext.fillRect(10 + x * this.NextBloclWidth*1.25, y * this.NextBloclHeight*2 + 5, this.NextBloclWidth*1.25, this.NextBloclHeight*2);
                    this.NextBlockContext.strokeRect(10 + x * this.NextBloclWidth*1.25, y * this.NextBloclHeight*2 + 5, this.NextBloclWidth*1.25, this.NextBloclHeight*2);
                }
            }
        }
    }
}