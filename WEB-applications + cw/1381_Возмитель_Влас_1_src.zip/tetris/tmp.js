for (let index = 0; index < 10; index++) {
    console.log(Math.floor(index / 3));
    
}