// function httpPost(value) {
//     if (value === "#") {
//         return;
//     }
//     const xhttp = new XMLHttpRequest()
//     xhttp.onload = () => {
//         document.getElementById("book_list").innerHTML = xhttp.responseText;
//         document.getElementById("filter_type").value = value;
//     };
//     xhttp.open("POST", `/books/filter`, true);
//     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//     xhttp.send(`option=${value}`);
// }
function httpPost() {

    var value = document.getElementById("filter_type").value; // получить значение сортировки

    // выполнить AJAX-запрос
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("book_list").innerHTML = this.responseText; // отобразить сортированные данные
        }
    };
    xhttp.open("POST", `/books/sort`, true);

    xhttp.send(`option=${value}`);
}