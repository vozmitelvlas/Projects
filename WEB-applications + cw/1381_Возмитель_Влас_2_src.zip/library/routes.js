const router = require("express").Router();
const { isNumeric } = require('validator');
let userName = "User";
let books = require("./books.json").books;
let tmpbook = books[0]

router.get("/", (req, res) => {
    res.render("input", {
        user_name: "User"
    });
});
router.post("/library", (req, res) => {
    if(req.body.user_name)
        userName = req.body.user_name === "" ? "User" : req.body.user_name;

    if(req.body.for_del){
        if(books[req.body.for_del]){
            for (let i = req.body.for_del; i < books.length; i++) {
                books[i].id -= 1
            }
        }
        books.splice(req.body.for_del - 1, 1) // удалил 2 эл
    }
    res.redirect("/library");
});

router.get("/library", (req, res) => {
    console.log(" first render")
    res.render("main", {
        user_name: userName,
        books: books
    });
});

router.get("/library/add", (req, res) => {
    res.render("adding", {
        user_name: userName,

    });
})
router.post("/library/adding", (req, res) =>{

    const addBook = {
        "id": books.length + 1,
        "title": req.body.title,
        "author": req.body.author,
        "year": req.body.year,
        "isTakenBy": null,
        "mustReturn": null,
        "available": true,
        "iconPath": "../public/images/default.jpg"
    }
    if(!addBook.title || !addBook.author || !isNumeric(addBook.year.toString())){
        res.status(400);
        res.json({message: "Bad request"});
    }
    else{
        books.push(addBook);
        res.redirect("/library");
    }
})
// router.post("/library/")

router.get("/library/:id([0-9]{1,})", (req, res) => {

    const url = req.url;
    const book_id = parseInt(url.slice(url.lastIndexOf('/') + 1));
    tmpbook = books.find((item) => item.id === book_id);
    console.log(book_id)
    res.render("book", {
        user_name: userName,
        books: books,
        book: tmpbook
    })
})

router.get("/library/:id([0-9]{1,})/take", (req, res) => {
    tmpbook.available = false
    tmpbook.isTakenBy = userName

    let currentDate = new Date();

    let formattedTime = currentDate.toLocaleTimeString();  // "час:минуты:секунды"
    currentDate.setMonth(currentDate.getMonth() + 1);// Прибавляем один месяц к дате

    let formattedNewDate = currentDate.toISOString().split("T")[0];  // "год-месяц-день"

    const date = formattedNewDate + ' ' + formattedTime

    tmpbook.mustReturn = date.slice();

    res.redirect("/library/" + req.params.id);
})

router.get("/library/:id([0-9]{1,})/return", (req, res) => {
    tmpbook.available = true
    tmpbook.isTakenBy = null
    tmpbook.mustReturn = null
    res.redirect("/library/" + req.params.id);
})

router.post("/library/:id([0-9]{1,})/edit", (req, res) =>{

    console.log(req.body)
    books[tmpbook.id - 1].title = req.body.new_title !== "" ? req.body.new_title : books[tmpbook.id - 1].title;
    books[tmpbook.id - 1].author = req.body.new_author !== "" ? req.body.new_author : books[tmpbook.id - 1].author;
    books[tmpbook.id - 1].year = req.body.new_year !== "" ? req.body.new_year : books[tmpbook.id - 1].year;

    res.redirect("/library/" + tmpbook.id);
})

router.post("/library/sort", (req, res) => {
    console.log(req.body.option)
    const type = req.body.option;

    let copyLibBooks = books.slice();
    switch (type) {
        case "all":
            break;
        case "by_title":
            copyLibBooks.sort((a, b) => (a.title > b.title) ? 1 : (a.title < b.title ? -1 : 0));
            break;
        case "available":
            copyLibBooks = copyLibBooks.filter((b) => {
                return b.available;
            });
            break;
        case "returnDate":
            copyLibBooks = copyLibBooks.filter((b) => {
                return !b.available;
            });
            copyLibBooks.sort((a, b) => {
                if (a.mustReturn && b.mustReturn) {
                    return (Date.parse(a.mustReturn) > Date.parse(b.mustReturn)) ? 1 :
                        (Date.parse(a.mustReturn) < Date.parse(b.mustReturn) ? -1 : 0);
                } else if (a.mustReturn) {
                    return 1;
                } else if (b.mustReturn) {
                    return -1;
                } else {
                    return 0;
                }
            });
            break;
    }
    console.log(" second render")
    res.render("main", {
        user_name: userName,
        books: copyLibBooks
    });

})
module.exports = router;