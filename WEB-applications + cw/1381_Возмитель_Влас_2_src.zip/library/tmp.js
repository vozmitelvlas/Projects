let currentDate = new Date();

let formattedTime = currentDate.toLocaleTimeString();  // "час:минуты:секунды"
currentDate.setMonth(currentDate.getMonth() + 1);// Прибавляем один месяц к дате

let formattedNewDate = currentDate.toISOString().split("T")[0];  // "год-месяц-день"

const res = formattedNewDate + ' ' + formattedTime