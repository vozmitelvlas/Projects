//const server = require("express")();
const fs = require("fs");
const https = require("https");
const private_key = fs.readFileSync("./key/server.key", "utf8")
const certificate = fs.readFileSync("./key/server.csr", "utf8")

if(process.argv[2])
  global.build_opt = process.argv[2];
else
  global.build_opt = "gulp";
global.build_dir = "build_" + global.build_opt + "/";

let express = require("express");
let server = express();

const bodyParser = require("body-parser");
server.use(bodyParser.urlencoded({ extended: true }));

server.set("view engine", "pug");
server.set("views", "./views");

server.use('/public', express.static('public'));
server.use('/views', express.static('views'));

server.use('/src', express.static('src'));

const routes = require("./routes");
server.use("/", routes);

const port = 3000;
const httpsServer = https.createServer({key: private_key, cert: certificate}, server);
httpsServer.listen(port);
