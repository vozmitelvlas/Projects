const router = require("express").Router();
let users = require("./users.json").users;
let news = require("./news.json").news;

function getRandomBirthdate() {
    // Генерируем случайный год от 1900 до 2022
    const year = Math.floor(Math.random() * (2023 - 1900) + 1900);

    // Генерируем случайный месяц от 1 до 12
    const month = Math.floor(Math.random() * 12) + 1;

    // Генерируем случайный день от 1 до 31, учитывая месяц и возможные дни в нем
    const day = Math.floor(Math.random() * (new Date(year, month, 0).getDate() - 1) + 1);

    // Форматируем дату в виде "YYYY-MM-DD"
    const birthdate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    return birthdate
}

for(elem of users){
    elem.birthdate = getRandomBirthdate();
}

router.get("/", (req, res) => {
    res.render("main", {
        user_name: "User",
        users: users
    });
});
router.get("/user/:id([0-9]{1,})", (req, res) => {

    const url = req.url;
    const user_id = parseInt(url.slice(url.lastIndexOf('/') + 1));
    user = users.find((item) => item.id === user_id);
    let friends = []
    let local_news = []
    let my_news = []

    for (friend_id of user.friends){
        let tmpFriend = users.find((item) => item.id === friend_id);
        friends.push(tmpFriend)
    }

    for(friend of friends){
        let tmp_id = friend.id
        for(i in news) {
            if(news[i].id_user === tmp_id){
                local_news.push(news[i])
            }
        }
    }

    for(elem of news){
        if(elem.id_user === user_id){
            my_news.push(elem)
        }
    }

    res.render("user", {
        user_name: user.name,
        user: user,
        friends: friends,
        friends_news: local_news,
        my_news: my_news
    })
})

router.post("/user/:id([0-9]{1,})", (req, res) =>{
    let tmp_user_id = req.params.id
    users[tmp_user_id].name = req.body.new_name !== "" ? req.body.new_name : users[tmp_user_id].name;
    users[tmp_user_id].birthdate = req.body.new_birthdate !== "" ? req.body.new_birthdate : users[tmp_user_id].birthdate;
    users[tmp_user_id].email = req.body.new_email !== "" ? req.body.new_email : users[tmp_user_id].email;
    users[tmp_user_id].role = req.body.new_role !== "" ? req.body.new_role : users[tmp_user_id].role;
    users[tmp_user_id].status = req.body.new_status !== "" ? req.body.new_status : users[tmp_user_id].status;

    res.redirect("/user/" + tmp_user_id);
})

module.exports = router;