import {AfterViewInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { Title } from '@angular/platform-browser';
import {Router} from "@angular/router";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private titleService: Title, private router: Router) {
  }

  mail = "";
  is_admin = false
  title = '';
  test(){
    return this.router.url !== '/news' && this.router.url !== '/main_page'
  }

  ngOnInit() {
    this.titleService.setTitle('Soc');
  }
}
