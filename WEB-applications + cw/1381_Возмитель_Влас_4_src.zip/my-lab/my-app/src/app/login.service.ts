import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: "root"
})

export class LoginService {
  constructor(private http: HttpClient) {}
  login(mail: string, password: string, on_login: () => void, on_error: (msg: string) => void) {
    this.http.post("http://localhost:4300/login",
      {mail, password})
      .subscribe((res:any) => {
        if(!res.error || res.error.length == 0){
          sessionStorage["my-lab_id"] = res.id;
          sessionStorage["my-lab_is_admin"] = res.is_admin;
          on_login();
        }
        else
          on_error(res.error);
      });
  }

  register(mail: string, birth:string, password: string, name: string) {
    this.http.post("http://localhost:4300/register", {mail, birth, password, name}).subscribe((res:any) => {
        console.log("reg == ", res)
        if(res.error && res.error.length != 0)
          alert("You already registered");
        else {
          alert("You register at SNFP");
          //window.location.href = "http://localhost:4200/main_page"
        }
      });
  }
}


