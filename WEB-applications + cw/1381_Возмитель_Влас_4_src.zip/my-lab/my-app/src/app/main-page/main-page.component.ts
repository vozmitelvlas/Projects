import {Component, OnInit} from '@angular/core';
import {MainPageService} from "../main-page.service";

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit{
  constructor(private main_page_service: MainPageService) {}
  photo_user_url = ''
  is_admin = false;
  name = ""
  mail = ""
  birth = ""
  status = ""
  role = ""
  friends_names = []
  friends_photos = []

  ngOnInit() {
    this.main_page_service.getPhoto(parseInt(sessionStorage["my-lab_id"]), (photo: string) => {this.photo_user_url = photo;})
    this.main_page_service.getInfo(parseInt(sessionStorage["my-lab_id"]), (name: string, mail: string, birth: string, status: string, role: string, friends_names: any, friends_photos: any) => {
      this.name = name; this.mail = mail; this.birth = birth; this.status = status; this.role = role; this.friends_names = friends_names; this.friends_photos = friends_photos})

  }
  test(){
    console.log("asss", this.friends_names, this.friends_photos);
    return true;
  }
}


