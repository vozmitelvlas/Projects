const express = require('express')
const app = express.Router()
let users = require("../../lab3/users.json")
const fs = require('fs')
let news = require("./news_storage.json")
const password = require("./pass.json")

function save(fl, _json){
    fs.writeFile(fl, JSON.stringify(_json), (error) => {if(error) throw error})
}
function get_id_by_mail(mail, local = users){
    for(let i = 0; i < local.users.length; i++){
        if(local.users[i].mail === mail)
            return i;
    }
}

app.post("/login", (req, res) => {
    if(password[req.body.mail] && password[req.body.mail] === req.body.password){
        res.end(JSON.stringify({id: get_id_by_mail(req.body.mail), is_admin: users.users[get_id_by_mail(req.body.mail)].role === 'Admin'}))
    }
    else{
        res.end(JSON.stringify({error: "Wrong login/password"}));
    }
})
app.post("/register", (req, res) => {
    console.log(req.body)
    if(get_id_by_mail(req.body.mail) != undefined){
        res.end(JSON.stringify({error: "User is already register"}));
        return;
    }
    console.log("1", req.body.name)
    users.users.push({id: users.users.length, mail: req.body.mail, name: req.body.name, birth: req.body.birth, role: "User", status: "Active", photo:"user.png", friends: [0,1,2]})
    password[req.body.mail] = req.body.password
    save("../../lab3/users.json", users)
    save("../my-lab/pass.json", password)
    res.end(JSON.stringify({}))
});
app.post("/user_photo", (req, res) => {
    let user = users.users[req.body.id];
    if(user){
        res.end(JSON.stringify({photo: 'https://localhost:3000/public/images/' + user.photo}))
    }
    else{
        res.end(JSON.stringify({error: "Wrong id"}))
    }
});
app.post("/user_info", (req, res) => {
    let friends_names = []
    let friends_photos = []
    let user = users.users[req.body.id];
    if(!user){
        res.end(JSON.stringify({error: "Wrong id"}));
        return;
    }
    else {
        for(let i = 0; i < user.friends.length; i++){
            let tmp_friend_id = user.friends[i]
            let friend = users.users.find(user => user.id === tmp_friend_id);
            friends_names.push(friend.name)
            friends_photos.push('https://localhost:3000/public/images/' + friend.photo)
        }
        res.end(JSON.stringify({name: user.name, mail: user.mail, birth: user.birth, status: user.status, role: user.role, friends_names: friends_names, friends_photos: friends_photos}))
    }
})
app.post("/news", (req, res)=>{
    let user = users.users[req.body.id];
    if(!user){
        res.end(JSON.stringify({error: "Wrong id"}));
        return;
    }

    let news_massive = []
    for(let i = 0; i < news.news.length; i++){
        if(news.news[i].id_user == req.body.id){
            news_massive.push({user_name: user.name, news_name: news.news[i].news_name, news_body: news.news[i].news_body, photo: news.news[i].photo})
        }
    }
    for(let i = 0; i < user.friends.length; i++){

        let tmp_id = user.friends[i]
        let friend = users.users.find(user => user.id === tmp_id);
        for(let i = 0; i < news.news.length; i++){
           // console.log(friend.id, "and", news.news[i].id_user, news.news[i].news_name)
            if(friend.id === news.news[i].id_user){
                news_massive.push({user_name: friend.name, news_name: news.news[i].news_name, news_body: news.news[i].news_body, photo: news.news[i].photo})
            }
        }
       // let friend_news = news.news.find(user => user.id === friend.id);
        //console.log("ass", friend_news)

       // news_massive.push({user_name: friend.name, news_name: friend_news.news_name, news_body: friend_news.news_body, photo: friend_news.photo})
    }
    res.end(JSON.stringify({news: news_massive}))
})
app.post("/add_news", (req, res) => {
    let user = users.users[req.body.id];
    if(!user){
        res.end(JSON.stringify({error: "Wrong id"}));
        return;
    }
    if(user.status == 'Blocked'){
        res.end(JSON.stringify({error: "User has been banned"}));
        return;
    }
    news.news.push({id: news.news.length, id_user: parseInt(req.body.id), news_name: req.body.news_name, news_body: req.body.news_body, photo: req.body.photo})
    save("./news_storage.json", news)
    global.server_io.sockets.emit('news')
    res.end(JSON.stringify({}))
})
module.exports = {app, get_id_by_mail};