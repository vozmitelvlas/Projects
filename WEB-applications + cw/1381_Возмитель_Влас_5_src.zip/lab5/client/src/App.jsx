import './App.css'
import {Route, Routes} from "react-router-dom";
import {useNavigate} from 'react-router-dom';
import Brokers from './Brokers';
import Stocks from './Stock';
import Trade from './Trade';
import React from "react";
function App() {
    const navigate = useNavigate();
    const toBrokers = () => { navigate("/brokers"); };
    const toStock = () => { navigate("/stocks"); };
    const toExchange = () => { navigate("/trade"); };
    return (
    <div>
        <div className="main_buttons">
            <button onClick={toBrokers}>Брокеры</button>
            <button onClick={toStock}>Акции</button>
            <button onClick={toExchange}>Торги</button>
        </div>
        <Routes>
            <Route path={"/brokers"} element={<Brokers/>}/>
            <Route path={"/stocks"} element={<Stocks/>}/>
            <Route path={"/trade"} element={<Trade/>}/>
        </Routes>
    </div>
    )
}

export default App
