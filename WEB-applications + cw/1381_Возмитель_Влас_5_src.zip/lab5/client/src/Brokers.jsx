import './Brokers.css';
import {useDispatch, useSelector} from "react-redux";
import {useState} from "react";
import React from "react";
import axios from "axios"
import {setBrokers} from "./store/broker-slice.jsx"

function Brokers() {

    const dispatch = useDispatch();
    const [name, setName] = useState('');
    const [cache, setCache] = useState(0);
    const [tmp_br, set_tmp_br] = useState('');
    let brokers = useSelector((state) => state.broker.brokers);

    axios.get("http://localhost:4000/brokers")
    .then((r) => {
        dispatch(setBrokers(r.data));
    });
    let list_of_brokers = useSelector((state) => {
        let br = state.broker.brokers;
        let ret = [];
        for(let id in br){
            let b = br[id];
            ret.push({name: b.name, cache: b.cache, id: id});
        }
        return ret;
    })

    let addBroker = () => {
        if(!list_of_brokers.find((item) => item.name.toLowerCase() === name.toLowerCase()) && name !== "")
            axios.post("http://localhost:4000/brokers", {name: name, cache: cache}).then(r => {
                dispatch(setBrokers(r.data))
            })
        else
            alert("false")
    }
    let changeCache = (event) => {
        axios.put("http://localhost:4000/brokers/" + tmp_br,
            {name: name, cache: Number(event.target.value)}).then(r => {
            dispatch(setBrokers(r.data))
        })
    }

    let start = () => {
        for(let i = 0; i < list_of_brokers.length; i++){
            let tmp = document.getElementById("cache" + i);
            tmp.disabled = true;
        }
    }

    let selectBroker = (event) => {
        start();
        let sel = event.target.id;
        set_tmp_br(sel);
        setName(brokers[sel].name);
        setCache(brokers[sel].cache);
        let tmp = document.getElementById("cache" + event.target.id);
        tmp.disabled = false;

    };
    let deleteBroker = () => {
        for(let i = 0; i < list_of_brokers.length; i++){
            let tmp = document.getElementById("cache" + i);
            console.log(tmp.id)
            if(!tmp.disabled){
                axios.delete("http://localhost:4000/brokers/" + tmp_br)
                    .then((r) => {
                        dispatch(setBrokers(r.data));
                    });
            }
        }
    }

    let cnt = 0;
    return(
        <div>
            <div>
                <h4>Имя</h4>
                <div className="container">
                    <input type="text" className="form_field" value={name} onChange={event => setName(event.target.value)}></input>
                </div>
                <h4>БабкиБабкиБабки:</h4>
                <div className="container">
                    <input type="number" className="form_field" value={cache} onChange={event => setCache(event.target.value)}></input>
                </div>
                <div className="container">
                    <button  onClick={addBroker}>Добавить</button>
                    <button onClick={deleteBroker}>Удалить</button>
                </div>
            </div>
            <div>
                <table className="table-fill">
                    <thead>
                    <tr>
                        <th></th>
                        <th className="text-left">Имя</th>
                        <th className="text-left">БабкиБабкиБабки</th>
                    </tr>
                    </thead>
                    <tbody id="data">
                    {list_of_brokers.map((tmp) => (
                        <tr key={tmp.id}>
                            <td><input
                                type="radio"
                                name="broker_chosen"
                                className="text-left"
                                id={tmp.id}
                                onChange={selectBroker}
                            /></td>
                            <td className="text-left">{tmp.name}</td>
                            <td className="text-left">
                                <input
                                    id={"cache" + cnt++}
                                    type="number"
                                    name="cache"
                                    value={tmp.cache}
                                    onChange={changeCache}
                                    disabled
                                />
                            </td>
                        </tr>
                    ))
                    }
                    </tbody>
                </table>
            </div>
        </div>
    )
}
export default Brokers
