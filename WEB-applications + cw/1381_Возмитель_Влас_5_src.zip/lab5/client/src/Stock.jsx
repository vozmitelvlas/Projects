import './Stock.css';
import React, {useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {disableStock, enableStock, setStocks, setTmpStock} from "./store/stock-slice.jsx";
import { Line } from 'react-chartjs-2';
import axios from "axios";
import Chart from 'chart.js/auto';

function Stock() {
    const dispatch = useDispatch();

    let chosen_stocks = useSelector((state) => state.stock.active_stocks);
    let tmp_history= useSelector((state) => {
        let history = state.stock.tmp_history;
        let res = [];
        for(let date in history){
            let tmp = history[date];
            res.push({date: date, open: tmp.Open, high: tmp.High, low: tmp.Low, close: tmp.Close});
        }
        res.length = 100;
        return res
    })
    let list_of_stocks = useSelector((state) => {
        let stocks = state.stock.stocks;
        let res = []
        for(let flag in stocks){
            res.push({flag: flag, name: stocks[flag].name});
        }
        return res;
    })

    axios.get("http://localhost:4000/stocks").then((r) => {
            dispatch(setStocks(r.data));
        });

    const [chart_data, setChart] = React.useState({
        labels: [],
        datasets: [
            {}
        ]});

    let TMPFopen = (event) => {
        window.myDialog.showModal()
        let flag = event.target.id
        axios.get("http://localhost:4000/stocks/" + flag).then(r => {
            dispatch(setTmpStock({flag: flag, history: r.data}))
            let dates = [], open = [], close = [], high = [], low = [];
            for(let date in r.data){
                dates.push(date);
                open.push(r.data[date].Open)
                high.push(r.data[date].High)
                low.push(r.data[date].Low)
                close.push(r.data[date].Close)
            }
            // изменить цвета
            setChart({
                labels: dates,
                datasets: [
                    {
                        label: "High",
                        data: high,
                        fill: false,
                        backgroundColor: 'green',
                        borderColor: 'green'
                    },
                    {
                        label: "Start",
                        data: open,
                        fill: false,
                        backgroundColor: 'orange',
                        borderColor: 'orange'
                    },
                    {
                        label: "Close",
                        data: close,
                        fill: false,
                        backgroundColor: 'black',
                        borderColor: 'black'
                    },
                    {
                        label: "Low",
                        data: low,
                        fill: false,
                        backgroundColor: 'red',
                        borderColor: 'red'
                    }
                ]
            })
        })
    }

    let TMPFclose = (event) => {
        window.myDialog.close()
    }
    let chosen = (event) => {
        let flag = event.target.id.substr("stock".length);
        console.log(event.target.id, flag)
        if(event.target.checked)
            dispatch(enableStock(flag));
        else
            dispatch(disableStock(flag));
    }
    return(
        <div>
            <table className="table-fill">
                <thead>
                <tr>
                    <th></th>
                    <th className="text-left">График</th>
                    <th className="text-left">Компания</th>
                    <th className="text-left">Обозначение на рынке</th>
                </tr>
                </thead>
                <tbody>
                    {list_of_stocks.map((tmp) => (
                        <tr key={tmp.flag}>
                            <td><input type="checkbox" id={"stock" + tmp.flag} onChange={chosen} checked={chosen_stocks[tmp.flag] === true}/></td>
                            <td><button id={tmp.flag} onClick={TMPFopen}>Graphic</button></td>
                            <td>{tmp.name}</td>
                            <td>{tmp.flag}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <dialog id="myDialog" className="hist_dialog">
                <button onClick={TMPFclose} style={{float: "right"}}>Закрыть</button>
                <div className="cont">
                    <table  className="table-fill">
                        <thead>
                            <tr>
                                <th className="text-left">Дата</th>
                                <th className="text-left">Цена открытия</th>
                                <th className="text-left">Минимальная цена</th>
                                <th className="text-left">Максимальная цена</th>
                                <th className="text-left">Цена закрытия</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tmp_history.map((tmp) => (
                                <tr key={tmp.date}>
                                    <td>{tmp.date}</td>
                                    <td>{tmp.open}</td>
                                    <td>{tmp.low}</td>
                                    <td>{tmp.high}</td>
                                    <td>{tmp.close}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <div>
                        <Line data={chart_data} options={{animation: {duration: 0}, pointRadius: 0, events: []}}/>
                    </div>
                </div>
            </dialog>
        </div>
    )
}
export default Stock