import './Trade.css';
import React, {useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {setDelta, setStartDate} from "./store/trade-slice.jsx";
import axios from "axios";
import socketio from 'socket.io-client';

function Trade() {
    let dispatch = useDispatch();
    let delta = useSelector((state) => state.trade.delta);
    let active_stocks = useSelector((state) => state.stock.active_stocks);
    let start_date = useSelector((state) => state.trade.start_date);

    let dateChosen = (event) => {
        dispatch(setStartDate(event.target.value))
    }
    let deltaChosen = (event) => {
        dispatch(setDelta(Number(event.target.value)))
    }
    let startTrade = (event) =>{
        let chosen_stocks = []
        for(let flag in active_stocks){
            if(active_stocks[flag]) chosen_stocks.push(flag);
        }
        axios.post("http://localhost:4000/trade", {start_date, delta, chosen_stocks})
    }

    let [stock_price, SetPrice] = useState([]);
    let [tmp_date, SetDate] = useState("");

    let socket = socketio.connect("http://localhost:4000/");
    socket.on("trading", (data) => {
        data = JSON.parse(data);
        let res = []
        for(let flag in data.tmp_prices){
            res.push({flag: flag, price: data.tmp_prices[flag]})
        }
        SetPrice(res);
        SetDate(data.tmp_date)

    });

    return(
        <div>
            <h4>Начальная дата</h4>
            <div className="container">
                <input type="date" className="form_field" value={start_date} onChange={dateChosen}></input>
            </div >
            <h4>Интервал</h4>
            <div className="container">
                <input type="number" className="form_field" value={delta} onChange={deltaChosen}></input>
            </div>
            <button className="container" onClick={startTrade}>Начало торгов</button>

            <table className="table-fill">
                <thead>
                <tr>
                    <th className="text-left">Дата</th>
                    <th className="text-left">Компания</th>
                    <th className="text-left">Цена акции</th>
                </tr>
                </thead>
                <tbody>
                {stock_price.map((tmp) => (
                    <tr key={tmp.flag}>
                        <td>{tmp_date}</td>
                        <td>{tmp.flag}</td>
                        <td>{tmp.price}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    )
}
export default Trade