import { createSlice } from '@reduxjs/toolkit';

export const stockSlice = createSlice({
    name: 'stock',
    initialState: {
        stocks: {},
        tmp_history: {},
        active_stocks: {}
    },
    reducers: {
        setStocks: (state, action) => {
            state.stocks = action.payload;
        },
        setTmpStock: (state, action) => {
            state.tmp_history = action.payload.history;
        },
        disableStock: (state, action) => {
            state.active_stocks[action.payload] = false;
        },
        enableStock: (state, action) => {
            state.active_stocks[action.payload] = true;
        }
    }
});

export const { setStocks, setTmpStock, enableStock, disableStock } = stockSlice.actions;
export default stockSlice.reducer;
