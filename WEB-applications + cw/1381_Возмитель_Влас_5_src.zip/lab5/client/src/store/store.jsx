import { configureStore } from '@reduxjs/toolkit';
import brokerReducer from './broker-slice';
import stockReducer from './stock-slice';
import tradeReducer from './trade-slice';

export const store = configureStore({
    reducer: {
        broker: brokerReducer,
        stock: stockReducer,
        trade: tradeReducer
    },
});

