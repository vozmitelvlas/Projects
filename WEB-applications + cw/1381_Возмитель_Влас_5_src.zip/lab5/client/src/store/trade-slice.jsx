import { createSlice } from '@reduxjs/toolkit';

export const tradeSlice = createSlice({
    name: 'trade',
    initialState: {
        start_date: "",
        delta: 1
    },
    reducers: {
        setStartDate: (state, action) => {
            state.start_date = action.payload;
        },
        setDelta: (state, action) => {
            state.delta = action.payload;
        }
    }
});

export const { setStartDate, setDelta } = tradeSlice.actions;
export default tradeSlice.reducer;
