console.log("asd", data)
import { readFileSync, writeFileSync } from 'fs';
let fd = readFileSync('../brokers.json');
let data = JSON.stringify(JSON.parse(fd.toString()));


const tableBody = document.getElementById("data");

for (let key in data) {
    if (data.hasOwnProperty(key)) {
        let row = document.createElement("tr");
        let nameCell = document.createElement("td");
        let moneyCell = document.createElement("td");

        nameCell.textContent = data[key].name;
        moneyCell.textContent = data[key].money;

        row.appendChild(nameCell);
        row.appendChild(moneyCell);

        tableBody.appendChild(row);
    }
}