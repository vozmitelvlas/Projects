import {Body, Controller, Delete, Get, Param, Post, Put} from '@nestjs/common';
import { BrokerService } from './broker.service';

@Controller('brokers')
export class BrokerController {
    constructor(private readonly brokerService: BrokerService) {}
    @Post()
    addBrokers(@Body() body: any): string{
        this.brokerService.addBroker(body.name, body.cache);
        //console.log("body=", body)
        return this.brokerService.getBrokers();
    }
    @Get()
    getBrokers(): string {
        return this.brokerService.getBrokers();
    }
    @Put(":id")
    changeCache(@Body() body: any, @Param("id") id): string{
        this.brokerService.changeCache(body.name, body.cache, id);
       // console.log("name new cache=", body)
        return this.brokerService.getBrokers();
    }
    @Delete(":id")
    deleteBroker(@Param("id") id): string{
        this.brokerService.deleteBroker(id);
        return this.brokerService.getBrokers();
    }
}
