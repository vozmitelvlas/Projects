import { Injectable } from '@nestjs/common';
import { readFileSync, writeFileSync } from 'fs';

@Injectable()
export class BrokerService {
    private readonly allBrokers: any;
    private count: any;
    private yourJson: any;
    private lab6json: any

    constructor() {
        this.yourJson = require('../../../brokers.json')
        this.count = Object.keys(this.yourJson).length
        this.lab6json = require('../../../../bla/brokers.json').brokers

        this.allBrokers = JSON.parse(readFileSync('../brokers.json').toString());
    }
    writeDown(): void{
        writeFileSync('../brokers.json', JSON.stringify(this.allBrokers))
    }
    getBrokers(): string {
        return JSON.stringify(this.allBrokers)
    }
    addBroker(name: string, cache: number): void{
        this.allBrokers[this.count] = {name: name, cache: cache};
        this.count += 1;
        this.writeDown();
        this.lab6json.push({id: this.lab6json.length, name: name, cache: cache})
    }
    changeCache(name: string, cache: number, id: number): void{
        this.allBrokers[id] = {name: name, cache: cache};
        this.writeDown();
    }
    deleteBroker(id: number): void{
        if(this.allBrokers[id]){
            delete this.allBrokers[id];
            this.count -= 1;
        }
        this.writeDown();
        this.fix()
    }
    fix(): void{
        let tmp = require('../../../brokers.json')
        let cnt = 0;
        Object.keys(this.allBrokers).forEach((key) =>{
            if(this.allBrokers[cnt] !== this.allBrokers[key]){
                this.allBrokers[cnt] = this.allBrokers[key];
                delete this.allBrokers[key];
            }
            cnt++
        })
        this.writeDown();

    }
}
