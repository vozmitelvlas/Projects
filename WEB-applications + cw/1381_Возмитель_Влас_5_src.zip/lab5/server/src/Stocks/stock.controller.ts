import {Body, Controller, Delete, Get, Param, Post, Put} from '@nestjs/common';
import { StockService } from './stock.service';

@Controller('stocks')
export class StockController {
    constructor(private readonly stockService: StockService) {}
    @Get()
    getStocks(): string {
        return this.stockService.getStocks();
    }
    @Get(":flag")
    getStockHistory(@Param("flag") flag): string {
        return this.stockService.getStockHistory(flag);
    }
}
