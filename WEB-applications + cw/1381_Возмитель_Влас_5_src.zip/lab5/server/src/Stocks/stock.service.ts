import { Injectable } from '@nestjs/common';
import { readFileSync } from 'fs';

@Injectable()
export class StockService {
    private readonly stocks: any;
    private yourJson: any;
    private count: number;

    constructor() {
        // this.yourJson = require('../../../../apple.json')
        // this.count = Object.keys(this.yourJson).length
        this.stocks = JSON.parse(readFileSync('../apple.json').toString());
    }
    getStocks(): string{
        let res = {}
        for(let flag in this.stocks){
            res[flag] = {name: this.stocks[flag].name}
        }
        return JSON.stringify(res)
    }
    getStockHistory(flag: string): string{
        return JSON.stringify(this.stocks[flag].history);
    }
}
