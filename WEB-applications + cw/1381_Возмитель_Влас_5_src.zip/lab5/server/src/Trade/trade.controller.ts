import {Body, Controller, Get, Post} from '@nestjs/common';
import {TradeService} from './trade.service';

@Controller('trade')
export class TradeController {
	constructor(private readonly trade: TradeService) {}
	@Post()
	startTrade(@Body() body: any): void {
		this.trade.startTrade(body.start_date, body.delta, body.chosen_stocks);
	}
	@Get('date')
	getDate(): string {
		if(this.trade.tmp_date){
			let date = this.trade.tmp_date.toISOString();
			date = date.substr(0, date.indexOf('T'));
			return date;
		}
		else{
			return "undefined";
		}
	}
}
