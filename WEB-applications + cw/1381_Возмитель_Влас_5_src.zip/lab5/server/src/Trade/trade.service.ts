import {Injectable } from '@nestjs/common';
import { SocketGateway } from '../socket.gateway';
import { readFileSync } from 'fs';

@Injectable()
export class TradeService {
	tmp_date: Date;
	private trade: any = null;
	private readonly stocks: any;
	private prev: any = {};
	private cnt: 0;
	constructor(private readonly socket: SocketGateway) {
		this.stocks = JSON.parse(readFileSync('../apple.json').toString());
	}

	startTrade(date: string, sec: number, chosen_stocks: string[]): void {
		if(this.trade) clearInterval(this.trade);
		this.tmp_date = new Date(date)

		this.trade = setInterval(() => {
			let ok = false;
			let tmp_prices = {}
			let tmp_date = this.tmp_date.toISOString().substr(0, 10);
			for(let i = 0; i < chosen_stocks.length; i++){
				let tmp_stock = this.stocks[chosen_stocks[i]];
				if(!tmp_stock.history[tmp_date]){
					tmp_prices[chosen_stocks[i]] = this.prev[chosen_stocks[i]];
					continue;
				}
				tmp_prices[chosen_stocks[i]] = tmp_stock.history[tmp_date].Open;
				ok = true;
			}
			if(!ok)
				++this.cnt;
			else
				this.cnt = 0;
			if(this.cnt >= 4){
				clearInterval(this.trade);
				this.trade = null;
			}

			this.socket.emit('trading', {tmp_prices, tmp_date});
			this.prev = tmp_prices;
			this.tmp_date.setDate(this.tmp_date.getDate() + 1);
		}, sec * 1000);
	}
}
