import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { BrokerController } from './Brokers/broker.controller';
import { BrokerService } from './Brokers/broker.service';
import { StockController } from './Stocks/stock.controller';
import { StockService } from './Stocks/stock.service';
import { TradeModule } from './Trade/trade.module';

@Module({
	imports: [TradeModule],
	controllers: [AppController, BrokerController, StockController],
	providers: [AppService, BrokerService, StockService]
})
export class AppModule {}
