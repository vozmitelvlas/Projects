import { WebSocketGateway, WebSocketServer, SubscribeMessage} from '@nestjs/websockets';
import { Socket, Server } from 'socket.io';

@WebSocketGateway()
export class SocketGateway {
	@WebSocketServer() server;
	emit(event: string, msg: any) {
		this.server.emit(event, JSON.stringify(msg));
	}
}

