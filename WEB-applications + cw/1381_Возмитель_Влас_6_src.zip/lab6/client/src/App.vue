<template>
  <div class="center">
    <div class="main_buttons">
      <router-link to="/enter">
          <button class="btn">Войти</button>
      </router-link>
      <router-link to="/admin">
        <button class="btn">Модуль "Админ"</button>
      </router-link>
      <router-link to="/trade">
        <button class="btn">Торги</button>
      </router-link>
    </div>
    <div class="center">
      <router-view/>
    </div>
  </div>
</template>

<style>
.center {
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;
  text-align: center;
}
html, body {
  margin: 0;
  padding: 0;
  background-image: url("./assets/back.jpg");
  min-height: 100vh;
  color: white;
}
#app{
  margin: 0 auto;
  padding: 0;
}
.main_buttons{
  margin: 20px;
}
a {
  font-weight: 500;
  color: #646cff;
  text-decoration: inherit;
}
a:hover {
  color: #535bf2;
}

body {
  margin: 0;
  display: flex;
  min-width: 320px;
  min-height: 100vh;
}

h1 {
  font-size: 3.2em;
  line-height: 1.1;
}

button {
  border-radius: 8px;
  border: 1px solid transparent;
  padding: 0.6em 1.2em;
  font-size: 1em;
  font-weight: 500;
  font-family: inherit;
  background-color: #1a1a1a;
  cursor: pointer;
  transition: border-color 0.25s;
}
button:hover {
  border-color: #4E5066FF;
}
button:focus,
button:focus-visible {
  outline: 4px auto -webkit-focus-ring-color;
}

@media (prefers-color-scheme: light) {
  :root {
    color: #213547;
    background-color: #ffffff;
  }
  a:hover {
    color: #4E5066FF;
  }
  button {
    background-color: rgba(255, 255, 255, 0.59);
  }
}
</style>