import io from 'socket.io-client';

class TradeService {
    constructor() {
        this.socket = io("localhost:4000");
    }
    setStock(ref, on_change) {
        this.socket.on('trading', (data) => {
            data = JSON.parse(data);
            let prices = [];
            for(let flag in data.tmp_prices)
                prices.push({flag: flag, price: data.tmp_prices[flag]});
            prices.sort((a, b) => {
                if(a.flag < b.flag) return -1;
                else if(a.flag > b.flag) return 1;
                return 0;
            });
            ref.commit('set_stock_prices', prices);
            ref.commit('set_stock_prices_raw', data.tmp_prices);
            ref.commit('set_tmp_date', data.tmp_date);
            ref.commit('set_stock_hist', {date: data.tmp_date, day: data.tmp_prices});
            if(on_change)
                on_change();
        });
    }
}

export default new TradeService();
