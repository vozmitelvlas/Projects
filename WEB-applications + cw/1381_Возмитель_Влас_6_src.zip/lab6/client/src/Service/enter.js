class EnterService
{
    enter(axios, store, on_login, on_error)
    {
        axios.post('http://localhost:3000/enter', {name: sessionStorage['name']})
            .then((res) => {
                if(!res.data.error){
                    console.log("enter", res.data)
                    store.commit('set_name', res.data.name);
                    store.commit('set_cache', res.data.cache);
                    store.commit('set_tmp_date', res.data.date);

                    let prices = [];
                    for(let flag in res.data.tmp_prices)
                        prices.push({flag, price: res.data.tmp_prices[flag]});
                    prices.sort((a, b) => {
                        if(a.flag < b.flag) return -1;
                        else if(a.flag > b.flag) return 1;
                        return 0;
                    });

                    store.commit('set_stock_prices', prices);
                    store.commit('set_chosen_stocks', res.data.bought_stocks);
                    store.commit('set_income', res.data.income);
                    on_login();
                }
                else
                    on_error(res.data.error);
            });
    }
}

export default new EnterService();
