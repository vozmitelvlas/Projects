<template>
  <table class="table-fill">
    <thead>
    <tr>
      <th class="text-left">Брокер</th>
      <th class="text-left">Бабки</th>
      <th class="text-left">Акции</th>
      <th class="text-left">Доходы</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for="broker in broker_data" :key="broker.name">
      <td class="text-left">{{broker.name}}</td>
      <td class="text-left">{{broker.cache}}</td>
      <td class="text-left">{{broker.stocks}}</td>
      <td>{{broker.income}}</td>
    </tr>
    </tbody>
  </table>
</template>
<script>
import TradeService from '../Service/Trade';

export default
{
  name: 'AdminComponent',
  components: {},

  data() { return {
    broker_data: []
  }},

  created() {
    this.update_info();
    TradeService.setStock(this.$store, () => this.update_info());
  },
  methods: {
    update_info() {
      this.axios.get("http://localhost:3000/admin/info")
          .then((res) => {
            console.log("res.data = ", res.data)
            let broker_data = [];
            for(let token in res.data.brokers_data){
              let broker = {};
              broker.name = res.data.brokers_data[token].name;
              console.log("res.data.brokers_data", res.data.brokers_data)
              console.log("res.data.brokers_money", res.data.brokers_money)
              broker.cache = res.data.brokers_money[broker.name] ? res.data.brokers_money[broker.name] : res.data.brokers_data[token].cache;
              if(res.data.brokers_income[broker.name]){
                broker.income = "";
                for(let tag in res.data.brokers_income[broker.name])
                  broker.income += tag + ": " + (res.data.brokers_income[broker.name][tag] + (this.$store.state.stock_prices_raw[tag] ? this.$store.state.stock_prices_raw[tag] * res.data.brokers_stocks[broker.name][tag] : 0)) + ", ";
                broker.income = broker.income.substr(0, broker.income.length - 2);
              }
              if(res.data.brokers_stocks[broker.name]){
                broker.stocks = "";
                for(let tag in res.data.brokers_stocks[broker.name])
                  broker.stocks += tag + ": " + res.data.brokers_stocks[broker.name][tag] + ", ";
                broker.stocks = broker.stocks.substr(0, broker.stocks.length - 2);
              }
              broker_data.push(broker);
            }
            this.broker_data = broker_data;
          });
    }
  }
}
</script>

<style>
@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);
@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100);

div.table-title {
  display: block;
  margin: auto;
  max-width: 600px;
  padding:5px;
  width: 100%;
}

.table-title h3 {
  color: #fafafa;
  font-size: 30px;
  font-weight: 400;
  font-style:normal;
  font-family: "Roboto", helvetica, arial, sans-serif;
  text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
  text-transform:uppercase;
}


/*** Table Styles **/

.table-fill {
  margin: 50px;
  background: white;
  border-radius:3px;
  border-collapse: collapse;
  height: 150px;
  max-width: 400px;
  padding:5px;
  width: 100%;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
  animation: float 5s infinite;
}

th {
  color:#D5DDE5;;
  background: rgba(0, 0, 0, 0.63);
  border-bottom:4px solid #9ea7af;
  border-right: 1px solid #343a45;
  font-size:20px;
  font-weight: 100;
  padding:24px;
  text-align:left;
  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  vertical-align:middle;
}

th:first-child {
  border-top-left-radius:3px;
}

th:last-child {
  border-top-right-radius:3px;
  border-right:none;
}

tr, input{
  border-top: 1px solid #C1C3D1;
  border-bottom-: 1px solid #C1C3D1;
  color:#666B85;
  font-size:16px;
  font-weight:normal;
  text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);
}

tr:hover td {
  background:#4E5066;
  color:#FFFFFF;
  border-top: 1px solid #22262e;
}

tr:first-child, input {
  border-top:none;
}

tr:last-child, input {
  border-bottom:none;
}

tr:nth-child(odd) td, input {
  background:#EBEBEB;
}

tr:nth-child(odd):hover td, input {
  background:#4E5066;
}

tr:last-child td:first-child, input {
  border-bottom-left-radius:3px;
}

tr:last-child td:last-child, input {
  border-bottom-right-radius:3px;
}

td, input {
  background:#FFFFFF;
  padding:5px;
  text-align:left;
  vertical-align:middle;
  font-weight:300;
  font-size:16px;
  text-shadow: -1px -1px 1px rgba(248, 9, 9, 0.1);
  border-right: 1px solid #C1C3D1;
}

td:last-child, input {
  border-right: 0px;
}

th.text-left {
  text-align: left;
}

th.text-center {
  text-align: center;
}

th.text-right {
  text-align: right;
}

td.text-left, input {
  text-align: left;
}
input{
  background-color: rgba(122, 122, 122, 0.98);
  border: none;
}
</style>