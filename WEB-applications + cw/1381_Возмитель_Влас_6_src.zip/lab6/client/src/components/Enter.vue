<template>
  <div>
    <h4>Введите имя</h4>
    <div class="container">
      <input type="text" class="form_field" v-model="name"/>
    </div>
    <div class="container">
      <button v-on:click="enter">Войти</button>
    </div>
    <div class="login_success" style="margin-top: 5vh">{{msg_success}}</div>
    <div class="login_error">{{msg_error}}</div>
  </div>
</template>
<script>
import EnterService from '../Service/enter';
export default {
  name: 'EnterComponent',
  components: {},
  data() {
    return {
    name: "",
    msg_success: "",
    msg_error: ""
  }},
  methods: {
    enter() {
      this.msg_success = "";
      this.msg_error = "";

      sessionStorage['name'] = this.name;
      EnterService.enter(this.axios, this.$store,
          () => this.msg_success = "Successful login",
          (err) => this.msg_error = err);
    }
  }
}
</script>
<style scoped>
.center{
  display: flex; /*элемент теперь флекс*/
  justify-content: center; /* По центру*/

}
.container{
  margin: 10px;
}
h4{
  margin: 0px;
  color: #dedede;
}
.form_field {
  width: 250px;
  background: #fff;
  color: #a3a3a3;
  font: inherit;
  box-shadow: 0 6px 10px 0 rgba(114, 114, 114, 0.78);
  border: 0;
  outline: 0;
  padding: 22px 18px;
  margin: 5px;
  border-radius: 8px;
}
</style>
