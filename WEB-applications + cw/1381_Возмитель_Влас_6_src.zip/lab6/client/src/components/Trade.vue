<template>
    Брокер: <h4>{{$store.state.name}}</h4>
    Текущая дата: <h4>{{$store.state.tmp_date}}</h4>
    Деньги: <h4>{{$store.state.money}}</h4>
    <div class="main_buttons">
        <button class="btn" onclick="window.Mydialog.showModal()">История торгов</button>
    </div>
    <table class="table-fill">
      <thead>
        <tr>
          <th class="text-left">Компания</th>
          <th class="text-left">Стоимость</th>
          <th class="text-left">Куплено</th>
          <th class="text-left">Доход</th>
          <th class="text-left">Действия</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="stock in $store.state.stock_prices" :key="stock.flag">
          <td>{{stock.flag}}</td>
          <td>{{stock.price}}</td>
          <td>{{$store.state.chosen_stocks[stock.flag] ? $store.state.chosen_stocks[stock.flag] : 0}}</td>
          <td>{{$store.state.income[stock.flag] ? ($store.state.income[stock.flag] + stock.price * ($store.state.chosen_stocks[stock.flag] ? $store.state.chosen_stocks[stock.flag] : 0)) : 0}}</td>
          <td>
            <input type="number" min="1" v-model="count[stock.flag]"/>
            <button :id=stock.flag v-on:click="buy">Купить</button>
            <button :id=stock.flag v-on:click="sell">Продать</button>
          </td>
        </tr>
      </tbody>
    </table>

    <dialog class="hist_dialog" id="Mydialog">
      <button class="hist_button" style="float:right" onclick="window.Mydialog.close()">Закрыть</button>
      <div style="height:100%">
        <Line
            :chart-options="histChartOptions"
            :chart-data="histChartData"
            :styles="{height:'95%'}"
        />
      </div>
    </dialog>
</template>
<script>
import TradeService from "../Service/Trade"
import { Line } from 'vue-chartjs';
import { Chart as ChartJS, Title, Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement } from 'chart.js';
ChartJS.register(Title, Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement);
export default {
  name: 'TradeComponent',
  components: {Line},
  data() {
    return {
      count: {},
      msg_error: "",
      histChartOptions: {responsive: true, maintainAspectRatio:false},
      histChartData: {
        labels: [],
        datasets: []
      }
  }},
  created() {
    TradeService.setStock(this.$store, () => {
      let labels = [];
      let sets = [];
      let colors = ['green', 'blue', 'red', 'orange', 'black'];
      for(let date in this.$store.state.stock_hist){
        if(new Date(date) > new Date(this.$store.state.tmp_date))
          continue;

        labels.push(date);
        let day = this.$store.state.stock_hist[date];
        for(let flag in day){
          let found_flag = false;
          for(let i = 0; i < sets.length; ++i)
            if(sets[i].label === flag){
              sets[i].data.push(day[flag]);
              found_flag = true;
            }
          if(!found_flag)
            sets.push({label: flag, data: [day[flag]], borderColor: colors[sets.length % colors.length]});
        }
      }
      this.histChartData.labels = labels;
      this.histChartData.datasets = sets;
    });
  },
  methods:{
    buy(event){
      let flag = event.target.id;
      let amt = this.count[flag];
      this.msg_error = "";
      this.axios.post("http://localhost:3000/trade/buy", {name: sessionStorage['name'], flag, amt})
          .then((res) => {
            if(!res.data.error){
              this.$store.commit('set_cache', res.data.money);
              this.$store.commit('set_chosen_stocks', res.data.stocks);
              console.log("buy = ", res.data.stocks);
              this.$store.commit('set_income', res.data.income);
            }
            else{
              this.msg_error = res.data.error;
            }
          });
    },
    sell(event) {
      let flag = event.target.id;
      let amt = this.count[flag];
      this.msg_error = "";
      this.axios.post("http://localhost:3000/trade/sell", {name: sessionStorage['name'], flag, amt})
          .then((res) => {
            if (!res.data.error) {
              this.$store.commit('set_cache', res.data.money);
              this.$store.commit('set_chosen_stocks', res.data.stocks);
              this.$store.commit('set_income', res.data.income);
            } else
              this.msg_error = res.data.error;
          });
    }
  }
}
</script>
<style>
@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);
@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100);

.hist_dialog {
  top: 15vh;
  width: 70vw;
  height: 70vh;
}

div.table-title {
  display: block;
  margin: auto;
  max-width: 600px;
  padding:5px;
  width: 100%;
}

.table-title h3 {
  color: #fafafa;
  font-size: 30px;
  font-weight: 400;
  font-style:normal;
  font-family: "Roboto", helvetica, arial, sans-serif;
  text-shadow: -1px -1px 1px rgba(0, 0, 0, 0.1);
  text-transform:uppercase;
}


/*** Table Styles **/

.table-fill {
  margin: 50px;
  background: white;
  border-radius:3px;
  border-collapse: collapse;
  height: 150px;
  max-width: 400px;
  padding:5px;
  width: 100%;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
  animation: float 5s infinite;
}

th {
  color:#D5DDE5;;
  background: rgba(0, 0, 0, 0.63);
  border-bottom:4px solid #9ea7af;
  border-right: 1px solid #343a45;
  font-size:20px;
  font-weight: 100;
  padding:24px;
  text-align:left;
  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  vertical-align:middle;
}

th:first-child {
  border-top-left-radius:3px;
}

th:last-child {
  border-top-right-radius:3px;
  border-right:none;
}

tr, input{
  border-top: 1px solid #C1C3D1;
  border-bottom-: 1px solid #C1C3D1;
  color:#666B85;
  font-size:16px;
  font-weight:normal;
  text-shadow: 0 1px 1px rgba(256, 256, 256, 0.1);
}

tr:hover td {
  background:#4E5066;
  color:#FFFFFF;
  border-top: 1px solid #22262e;
}

tr:first-child, input {
  border-top:none;
}

tr:last-child, input {
  border-bottom:none;
}

tr:nth-child(odd) td, input {
  background:#EBEBEB;
}

tr:nth-child(odd):hover td, input {
  background:#4E5066;
}

tr:last-child td:first-child, input {
  border-bottom-left-radius:3px;
}

tr:last-child td:last-child, input {
  border-bottom-right-radius:3px;
}

td, input {
  background:#FFFFFF;
  padding:5px;
  text-align:left;
  vertical-align:middle;
  font-weight:300;
  font-size:16px;
  text-shadow: -1px -1px 1px rgba(248, 9, 9, 0.1);
  border-right: 1px solid #C1C3D1;
}

td:last-child, input {
  border-right: 0px;
}

th.text-left {
  text-align: left;
}

th.text-center {
  text-align: center;
}

th.text-right {
  text-align: right;
}

td.text-left, input {
  text-align: left;
}
input{
  background-color: rgba(122, 122, 122, 0.98);
  border: none;
}
</style>
