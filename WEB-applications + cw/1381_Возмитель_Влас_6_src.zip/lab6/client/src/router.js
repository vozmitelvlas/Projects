import { createRouter, createWebHashHistory } from 'vue-router';

const routes = [
    { path: '/enter', name: 'Register', component: () => import('./components/Enter.vue') },
     { path: '/trade', name: 'Trade', component: () => import('./components/Trade') },
     { path: '/admin', name: 'Admin', component: () => import('./components/Admin') }
]
const router = createRouter({
    history: createWebHashHistory(),
    routes
})
router.beforeEach((to)=>{document.title = to.name;})
export default router

