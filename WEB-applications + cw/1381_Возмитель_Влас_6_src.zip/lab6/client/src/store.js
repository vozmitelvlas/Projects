import { createStore } from 'vuex';
export default createStore({
    state() { return {
        tmp_date: "",
        money: 0,
        name: "",
        stock_prices: {},
        stock_prices_raw: {},
        stock_hist: {},
        chosen_stocks: {},
        income: {}
    }},
    mutations: {
        set_cache(state, cache) { state.money = cache; },
        set_name(state, name) { state.name = name; },
        set_stock_prices(state, prices) { state.stock_prices = prices; },
        set_stock_prices_raw(state, prices) { state.stock_prices_raw = prices; },
        set_stock_hist(state, payload) { state.stock_hist[payload.date] = payload.day; },
        set_tmp_date(state, date) { state.tmp_date = date; },
        set_chosen_stocks(state, stocks) { state.chosen_stocks = stocks; },
        set_income(state, income) { state.income = income; }
    }
});