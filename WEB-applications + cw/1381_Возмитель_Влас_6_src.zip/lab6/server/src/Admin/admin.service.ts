import { Injectable } from '@nestjs/common';
import { TradeService } from '../Trade/trade.service';
import { EnterService } from '../Enter/enter.service';

@Injectable()
export class AdminService {
    constructor(private readonly trade : TradeService, private readonly enter: EnterService) {}
    getAllInfo() {
        return {
            brokers_money: this.trade.brokers_money,
            brokers_stocks: this.trade.brokers_stocks,
            brokers_income: this.trade.brokers_income,
            brokers_data: this.enter.allBrokers
        };
    }
}
