import { Controller, Post, Body } from '@nestjs/common';
import { EnterService } from './enter.service';

@Controller('enter')
export class EnterController {
    constructor(private readonly enter: EnterService) {}
    @Post()
    enterUser(@Body() body: any): string {
        return JSON.stringify(this.enter.enterUser(body.name));
    }
}
