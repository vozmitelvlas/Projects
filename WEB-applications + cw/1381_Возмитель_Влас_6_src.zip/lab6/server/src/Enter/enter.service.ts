import { Injectable } from '@nestjs/common';
import { readFileSync } from 'fs';
import { TradeService } from '../Trade/trade.service';

@Injectable()
export class EnterService {
    allBrokers: any;
    private yourJson: any;
    private count: number;
    private id: string

    constructor(private readonly trade: TradeService) {
        this.yourJson = require('../../../brokers.json').brokers
        this.allBrokers = JSON.parse(readFileSync('../../empty/brokers.json').toString());
    }
    enterUser(name: string) {
        this.allBrokers = JSON.parse(readFileSync('../../empty/brokers.json').toString());
        for(let id in this.allBrokers){
            if(this.allBrokers[id].name === name){
                this.id = id
                break;
            }
        }
        let tmp_broker = this.allBrokers[this.id];
        if(tmp_broker){
            this.trade.getTmpPricesSync();
            let tmp_prices = {};
            let bought_stocks = this.trade.brokers_stocks[name] ? this.trade.brokers_stocks[name] : {};
            for(let tag in bought_stocks)
                tmp_prices[tag] = this.trade.tmp_prices[tag];
            let income = this.trade.brokers_income[name] ? this.trade.brokers_income[name] : {};
            return {
                name: tmp_broker.name,
                cache: this.trade.setBrokerMoney(name, tmp_broker.cache),
                date: this.trade.tmp_date,
                bought_stocks: bought_stocks,
                tmp_prices: tmp_prices,
                income: income
            }
        }
        else
            return {error: "No such broker \"" + name + '"'};

    }
}
