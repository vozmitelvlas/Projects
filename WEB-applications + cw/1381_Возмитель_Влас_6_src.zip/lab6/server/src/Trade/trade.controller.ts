import { Controller, Body, Post } from '@nestjs/common';
import { TradeService } from './trade.service';

@Controller('trade')
export class TradeController {
    constructor(private readonly trade: TradeService) {}
    @Post('buy')
    async buyStocks(@Body() body: any) {
        return await this.trade.buyStocks(body.name, body.flag, body.amt);
    }
    @Post('sell')
    async sellStocks(@Body() body: any) {
        return await this.trade.sellStocks(body.name, body.flag, body.amt);
    }
}
