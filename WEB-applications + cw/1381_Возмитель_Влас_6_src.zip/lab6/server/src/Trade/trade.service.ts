import { Injectable } from '@nestjs/common';
import { readFileSync } from 'fs';
import {lastValueFrom, map} from "rxjs";
import { HttpService } from '@nestjs/axios';

@Injectable()
export class TradeService {
    stocks: any;
    tmp_date = "";
    tmp_prices = {};
    brokers_stocks = {};
    brokers_income = {};
    brokers_money = {}
    constructor(private readonly httpService: HttpService) {
        this.stocks = JSON.parse(readFileSync('../../empty/apple.json').toString());
        this.getCurrentPrices();
    }
    calculateStocks(name: string, flag: string, amt: number){
        if(!this.brokers_stocks[name])
            this.brokers_stocks[name] = {};
        if(!this.brokers_stocks[name][flag] && amt > 0)
            this.brokers_stocks[name][flag] = amt;
        else if(this.brokers_stocks[name][flag])
            this.brokers_stocks[name][flag] = Math.max(this.brokers_stocks[name][flag] + amt, 0);
    }

    calculateIncome(name: string, flag: string, cache: number){
        if(!this.brokers_income[name])
            this.brokers_income[name] = {};
        if(!this.brokers_income[name][flag])
            this.brokers_income[name][flag] = cache;
        else
            this.brokers_income[name][flag] += cache;

    }
    async buyStocks(name: string, flag: string, cnt: number){
        if(!this.brokers_money[name]) return {error: "Unknown user"};
        await this.getCurrentPrices();

        let topay = cnt * this.tmp_prices[flag];

        if(topay === null) {
            return {error: "No such action"};
        }
        if(cnt === undefined || cnt === null){
            return {error: "Wrong action count"};
        }
        if(this.brokers_money[name] < topay) {
            return {error: "No money"};
        }

        this.calculateStocks(name, flag, cnt);
        this.calculateIncome(name, flag, -topay);
        this.brokers_money[name] -= topay;
        console.log("after buy", this.brokers_money);
        return {money: this.brokers_money[name], stocks: this.brokers_stocks[name], income: this.brokers_income[name]};
    }
    async sellStocks(name: string, flag: string, cnt: number){
        if(!this.brokers_money[name]) return {error: "Unknown user"};

        await this.getCurrentPrices();
        if(!this.brokers_stocks[name]) cnt = 0;
        else if(!this.brokers_stocks[name][flag]) cnt = 0;
        else cnt = Math.min(this.brokers_stocks[name][flag], cnt);
        let togain = cnt * this.tmp_prices[flag];

        this.calculateStocks(name, flag, -cnt);
        this.calculateIncome(name, flag, togain);
        this.brokers_money[name] += togain;
        return {money: this.brokers_money[name], stocks: this.brokers_stocks[name], income: this.brokers_income[name]};
    }

    async getCurrentPrices(){
        let res = await lastValueFrom(this.httpService.get('http://localhost:4000/trade/date').pipe(
            map(resp => resp.data)
        ));
        if(this.tmp_date != res){
            this.tmp_date = res;
            if(this.tmp_date !== "undefined")
                this.getTmpPricesSync();
        }
    }

    setBrokerMoney(name: string, cache: number): number {
        if(!this.brokers_money[name]){
            this.brokers_money[name] = cache;
        }
        return this.brokers_money[name];
    }

    getTmpPricesSync(){
        for(let flag in this.stocks){
            let day_hist = this.stocks[flag].history[this.tmp_date];
            if(day_hist)
                this.tmp_prices[flag] = day_hist.Open;
            else{
                let date = new Date(this.tmp_date);
                for(let i = 0; i < 4; ++i){
                    date.setDate(date.getDate() - 1);
                    let iso_date = "";
                    try {
                        iso_date = date.toISOString();
                        iso_date = iso_date.substr(0, iso_date.indexOf('T'));
                    }
                    catch {}
                    if(iso_date != ""){
                        day_hist = this.stocks[flag].history[iso_date];
                        if(day_hist){
                            this.tmp_prices[flag] = day_hist.Open;
                            break;
                        }
                    }
                }
            }
        }

    }

}
