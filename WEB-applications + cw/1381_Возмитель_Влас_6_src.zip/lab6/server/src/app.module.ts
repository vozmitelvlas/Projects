import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import {TradeService} from "./Trade/trade.service";
import {TradeController} from "./Trade/trade.controller";
import {HttpModule} from "@nestjs/axios";
import {AdminService} from "./Admin/admin.service";
import {AdminController} from "./Admin/admin.controller";
import {EnterController} from "./Enter/enter.controller";
import {EnterService} from "./Enter/enter.service";

@Module({
  imports: [HttpModule],
  controllers: [AppController, EnterController, TradeController, AdminController],
  providers: [AppService, EnterService, TradeService, AdminService],
})
export class AppModule {}
