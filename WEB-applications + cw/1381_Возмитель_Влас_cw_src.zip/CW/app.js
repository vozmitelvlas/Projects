//const server = require("express")();
let express = require("express");
let server = express();

const bodyParser = require("body-parser");
server.use(bodyParser.urlencoded({ extended: true }));

server.set("view engine", "pug");
server.set("views", "./views");

server.use('/public', express.static('public'));
server.use('/src', express.static('src'));

const routes = require("./routes");
server.use("/", routes);

const port = 3000;
server.listen(port, () => {
  console.log(`Server starts listening on port ${port}`)
});
