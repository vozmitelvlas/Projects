const router = require("express").Router();
let lvl = 0

router.post("/game", (req, res) => {
    const currentTime = new Date().getTime();
    lvl = req.body.level
    console.log(req.body)
    res.render("main", {
        currentTime,
        user_name: req.body.user_name
    });
});
router.get("/game", (req, res) => {
    const currentTime = new Date().getTime();
    res.render("main", {
        level: lvl,
        currentTime,
        user_name: req.body.user_name,
    });
});
router.get("/", (req, res) => {
    res.render("register", {
    });
});
router.get("/end", (req, res) => {
    res.render("end", {
    });
});

module.exports = router;