import {ctx, gameManager, mapManager, physicManager, soundManager, spriteManager} from "./main.js";

export class Entity{
    constructor() {
        this.pos_x = 0;
        this.pos_y = 0;
        this.size_x = 0;
        this.size_y = 0;
    }
}
export class Player extends Entity{
    constructor() {
        super();
        this.lifetime = 100;
        this.move_x = 0;
        this.move_y = 0;
        this.last_position = "";
        this.speed = 20;
        this.cash = 0;
    }
    draw(ctx){
        switch (true){
            case(this.move_x === 0 && this.move_y === -1):
                spriteManager.drawSprite(ctx, "tank_kt_up", this.pos_x, this.pos_y);
                this.last_position = "up";
                break;
            case (this.move_x === 0 && this.move_y === 1):
                spriteManager.drawSprite(ctx, "tank_kt_down", this.pos_x, this.pos_y);
                this.last_position = "down";
                break;
            case (this.move_x === 1 && this.move_y === 0):
                spriteManager.drawSprite(ctx, "tank_kt_right", this.pos_x, this.pos_y);
                this.last_position = "right";
                break;
            case (this.move_x === -1 && this.move_y === 0):
                spriteManager.drawSprite(ctx, "tank_kt_left", this.pos_x, this.pos_y);
                this.last_position = "left";
                break;
            default:
                switch (this.last_position){
                    case ("up"):
                        spriteManager.drawSprite(ctx, "tank_kt_up", this.pos_x, this.pos_y);
                        this.last_position = "up"
                        break;
                    case ("down"):
                        spriteManager.drawSprite(ctx, "tank_kt_down", this.pos_x, this.pos_y);
                        this.last_position = "down"
                        break;
                    case ("right"):
                        spriteManager.drawSprite(ctx, "tank_kt_right", this.pos_x, this.pos_y);
                        this.last_position = "right"
                        break;
                    case ("left"):
                        spriteManager.drawSprite(ctx, "tank_kt_left", this.pos_x, this.pos_y);
                        this.last_position = "left"
                        break;
                    default:
                        spriteManager.drawSprite(ctx, "tank_kt_right", this.pos_x, this.pos_y);
                        this.last_position = "right"
                        break;
                }
        }

    }
    update(){
        physicManager.update(this)
    }
    onTouchEntity(obj){
        if(obj.name.match(/coin[\d*]/)){
            this.cash += 1;
            obj.kill()
        }
    }
    kill(){
        this.lifetime = 0;
        gameManager.kill(this);
        gameManager.end();
    }
    fire(){
        let r = new Rocket();
        r.size_x = 64;
        r.size_y = 64;
        r.name = "rocket" + (++gameManager.fireNum);
        r.move_x = this.move_x;
        r.move_y = this.move_y;
        switch (this.move_x + 2 * this.move_y) {
            case -1:
                r.pos_x = this.pos_x - r.size_x;
                r.pos_y = this.pos_y;
                break;
            case 1:
                r.pos_x = this.pos_x + this.size_x;
                r.pos_y = this.pos_y;
                break;
            case -2:
                r.pos_x = this.pos_x;
                r.pos_y = this.pos_y - r.size_y;
                break;
            case 2:
                r.pos_x = this.pos_x;
                r.pos_y = this.pos_y + this.size_y;
                break;
            default: return;
        }
        if(soundManager.loaded && soundManager.isPlaying)
            soundManager.play('../public/fire.mp3', { volume: 0.2, looping: false });
        gameManager.entities.push(r);
    }
}

export class Tank extends Entity{
    constructor() {
        super();
        this.lifetime = 100;
        this.move_x = 0;
        this.move_y = 0;
        this.speed = 20;
        this.last_position = "";
        this.LastPosition = {x: 0, y: 0};
        this.lastPlayerPosX = 1;
        this.lastPlayerPosY = 1;
        this.canShoot = true;
    }


    draw(ctx){
        switch (true){
            case(this.move_x === 0 && this.move_y === -1):
                spriteManager.drawSprite(ctx, "tank_ter_up", this.pos_x, this.pos_y);
                this.last_position = "up";
                break;
            case (this.move_x === 0 && this.move_y === 1):
                spriteManager.drawSprite(ctx, "tank_ter_down", this.pos_x, this.pos_y);
                this.last_position = "down";
                break;
            case (this.move_x === 1 && this.move_y === 0):
                spriteManager.drawSprite(ctx, "tank_ter_right", this.pos_x, this.pos_y);
                this.last_position = "right";
                break;
            case (this.move_x === -1 && this.move_y === 0):
                spriteManager.drawSprite(ctx, "tank_ter_left", this.pos_x, this.pos_y);
                this.last_position = "left";
                break;
            default:
                switch (this.last_position){
                    case ("up"):
                        spriteManager.drawSprite(ctx, "tank_ter_up", this.pos_x, this.pos_y);
                        this.last_position = "up"
                        break;
                    case ("down"):
                        spriteManager.drawSprite(ctx, "tank_ter_down", this.pos_x, this.pos_y);
                        this.last_position = "down"
                        break;
                    case ("right"):
                        spriteManager.drawSprite(ctx, "tank_ter_right", this.pos_x, this.pos_y);
                        this.last_position = "right"
                        break;
                    case ("left"):
                        spriteManager.drawSprite(ctx, "tank_ter_left", this.pos_x, this.pos_y);
                        this.last_position = "left"
                        break;
                    default:
                        spriteManager.drawSprite(ctx, "tank_ter_up", this.pos_x, this.pos_y);
                        this.last_position = "up"
                        break;
                }
        }
    }
    update(){
        physicManager.update(this)
    }
    onTouchEntity(obj){
        if(!obj.name.startsWith("coin")){
            obj.kill()
        }
    }
    kill(){
        this.lifetime = 0;
        gameManager.kill(this);
        physicManager.addNewEnemy = true;
    }
    async Attack() {
        let playerX = physicManager.player_x;
        let playerY = physicManager.player_y;
        let ePX = Math.floor(this.pos_x / 128);
        let ePY = Math.floor(this.pos_y / 128);

        let res = await physicManager.findPlayer(playerX, playerY, ePX, ePY);
        if (res === -1) {
            physicManager.playerHasMoved = true;
            return;
        }

        let path = res.map(coords => {
            const [x, y] = coords.split('x').map(Number);
            return {x, y};
        });

        for (const nextStep of path) {
            const dx = nextStep.x - Math.floor(Math.round(this.pos_x / 128));
            const dy = nextStep.y - Math.floor(Math.round(this.pos_y / 128));

            if ((dx !== 0 && dy !== 0) || (dx > 1) || (dx < -1) || dy > 1 || dy < -1) {
                this.move_x = 0;
                this.move_y = 0;
                physicManager.playerHasMoved = true;
            }

            this.move_x = dx;
            this.move_y = dy;
            this.fire();

            while (Math.abs((this.pos_x) - nextStep.x * 128 - 32) > 10 || Math.abs((this.pos_y) - nextStep.y * 128 - 32) > 10) {
                if (this.lifetime <= 0) return;

                await new Promise(resolve => setTimeout(resolve, 1));
            }

            this.move_x = 0;
            this.move_y = 0;
            if (physicManager.player_x !== this.lastPlayerPosX || physicManager.player_y !== this.lastPlayerPosY) {
                this.lastPlayerPosX = physicManager.player_x;
                this.lastPlayerPosY = physicManager.player_y;
                physicManager.playerHasMoved = true;
                return;
            }
        }
    }
    fire(){
        if(this.move_x!==0 && this.move_y!==0) return;
        if(!this.canShoot) return;

        let r = new Rocket();
        r.size_x = 64;
        r.size_y = 64;
        r.name = "rocket"+(++gameManager.fireNum);
        r.move_x = this.move_x;
        r.move_y = this.move_y;
        console.log(r.move_x, r.move_y)

        switch (this.move_x + 2*this.move_y){
            case -1:
                r.pos_x = this.pos_x - this.size_x - r.size_y / 2;
                r.pos_y = this.pos_y + r.size_y / 8;
                break;
            case 1:
                r.pos_x = this.pos_x + this.size_x + r.size_y / 2;
                r.pos_y = this.pos_y + r.size_y / 2 - r.size_y / 2;
                break;
            case -2:
                r.pos_x = this.pos_x  + r.size_x / 8;
                r.pos_y = this.pos_y - r.size_y - r.size_y / 2;
                break;
            case 2:
                console.log("down")
                r.pos_x = this.pos_x + r.size_x - r.size_x;
                r.pos_y = this.pos_y + r.size_y + r.size_y;
                break;
            default:
                return;
        }
        if(soundManager.loaded && soundManager.isPlaying)
            soundManager.play('../public/fire.mp3', { volume: 0.2, looping: false });
        gameManager.entities.push(r);
        this.canShoot = false;

        setTimeout(() => {
            this.canShoot = true;
        }, 1500);
    }
}

export class Rocket extends Entity{
    constructor() {
        super();
        this.name = "";
        this.move_x = 0;
        this.move_y = 0;
        this.speed = 32;
    }
    draw(ctx) {
        switch (true) {
            case(this.move_x === 0 && this.move_y === -1):
                spriteManager.drawSprite(ctx, "rocket_up", this.pos_x, this.pos_y);
                this.last_position = "up";
                break;
            case (this.move_x === 0 && this.move_y === 1):
                spriteManager.drawSprite(ctx, "rocket_down", this.pos_x, this.pos_y);
                this.last_position = "down";
                break;
            case (this.move_x === 1 && this.move_y === 0):
                spriteManager.drawSprite(ctx, "rocket_right", this.pos_x, this.pos_y);
                this.last_position = "right";
                break;
            case (this.move_x === -1 && this.move_y === 0):
                spriteManager.drawSprite(ctx, "rocket_left", this.pos_x, this.pos_y);
                this.last_position = "left";
                break;
        }
    }
    update(){
        physicManager.update(this);
    }
    onTouchEntity(obj){
        if(obj.name.match(/enemy/) ||
            obj.name.match(/player/)
            ){
            obj.kill()
        }
        this.kill();
    }
    onTouchMap(){
        this.kill();
    }
    kill(){
        gameManager.kill(this);
    }
}

export class Bonus extends Entity{
    draw(ctx){
        spriteManager.drawSprite(ctx, "coin", this.pos_x, this.pos_y);
    }
    kill(){
        if(soundManager.loaded && soundManager.isPlaying)
            soundManager.play('../public/bonus.mp3', { volume: 0.2, looping: false });
        gameManager.kill(this);
    }
}