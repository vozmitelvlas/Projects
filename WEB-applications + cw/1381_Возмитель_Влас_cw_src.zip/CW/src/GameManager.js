import {Bonus, Player, Rocket, Tank} from "./Entity.js";
import {
    recorder,
    ctx,
    canvas,
    eventsManager,
    mapManager,
    spriteManager,
    gameManager,
    physicManager
} from "./main.js"

export class GameManager{
    constructor() {
        this.factory = {};
        this.entities = [];
        this.fireNum = 0;
        this.player = null;
        this.laterKill = [];
        this.time = "";
        this.mapNum = ""
}
    initPlayer(obj) {
        this.player = obj;
    }

    end(){
        const timerElement = document.getElementById('timer');
        this.time = timerElement.textContent;
        if(this.player.lifetime === 0){
            recorder.record.score = "0:0:0:0"
        }
        else{
            recorder.record.score = this.time;
        }

        recorder.record.map = this.mapNum;
        recorder.writeResults()
        window.location.href = "http://localhost:3000/end";
    }

    kill(obj){
        this.laterKill.push(obj);
    }
    update(){
        let cnt = 1;
        if(this.player === null)
            return;

        if(this.player.cash === 1){
            this.end();
            return;
        }
        this.player.move_x = 0;
        this.player.move_y = 0;
        if(eventsManager.action["down"] && eventsManager.action["right"] ||
            eventsManager.action["down"] && eventsManager.action["left"] ||
            eventsManager.action["up"] && eventsManager.action["right"] ||
            eventsManager.action["up"] && eventsManager.action["left"]) cnt++

        if(cnt === 1){
            if (eventsManager.action["up"]){
                this.player.move_y = -1;

            }
            if (eventsManager.action["down"]) this.player.move_y = 1;
            if (eventsManager.action["left"]) this.player.move_x = -1;
            if (eventsManager.action["right"]) this.player.move_x = 1;
            if (eventsManager.action["fire"]) this.player.fire();
        }

        this.entities.forEach(function(e) {
            try {
                if(e.name.startsWith("enemy")) {
                   // console.log(e.name, e.type)
                    if (physicManager.playerHasMoved) {
                        physicManager.playerHasMoved = false;
                        e.Attack();
                    }
                }
                e.update();
            } catch(ex) {}
        });
        for(let i = 0; i < this.laterKill.length; i++) {
            let idx = this.entities.indexOf(this.laterKill[i]);
            if(idx > -1)
                this.entities.splice(idx, 1);
        }
        if(this.laterKill.length > 0)
            this.laterKill.length = 0;
        mapManager.draw(ctx);
        mapManager.centerAt(this.player.pos_x, this.player.pos_y);
        this.draw(ctx);
        if(physicManager.addNewEnemy){
            mapManager.createEnemy();
            physicManager.addNewEnemy = false;
            physicManager.playerHasMoved = true;
        }


    }
    draw(ctx){
        for(let e = 0; e < this.entities.length; e++){
            this.entities[e].draw(ctx);
        }

    }
    loadAll(jsonPath, mapNum){
        this.mapNum = mapNum;
        mapManager.loadMap(jsonPath)
            .then(() => {
                spriteManager.loadAtlas("./src/atlas.json", "../public/images/spritesheet.png");
                this.factory['Player'] = Player;
                this.factory['Tank'] = Tank;
                this.factory['Bonus'] = Bonus;
                this.factory['Rocket'] = Rocket;
                mapManager.parseEntities();
                mapManager.draw(ctx);
                eventsManager.setup(canvas);
                physicManager.setData(mapManager.mazeMap);
        })
        .catch(error => {
            console.error("Ошибка загрузки карты:", error);
        });
    }
    play(){
        setInterval(this.updateWorld, 100)
    }
    updateWorld(){
        gameManager.update();

    }
}