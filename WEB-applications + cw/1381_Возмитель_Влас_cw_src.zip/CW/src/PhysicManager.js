import {gameManager, mapManager} from "./main.js";

export class PhysicManager {
    constructor() {
        this.player_x = 1;
        this.player_y = 1;
        this.map = [];
        this.playerHasMoved = true;
        this.ind = {
            player : -1,
            wall : [233, 238, 239, 259, 299, 293, 220, 258, 278],
            noth: 1,
            enemy: -2
        }
        this.addNewEnemy = false;
    }
    setData(map){
        this.map = map;
        this.map[this.player_y][this.player_x] = this.ind.player;
    }
    async findPlayer(playerX, playerY, startX,  startY) {  //async???

        let targetX = playerX;
        let targetY = playerY;
        if(this.ind.wall.includes(this.map[targetY][targetX])){
            console.log("игрок в стене");
            return -1;
        }

        let start = {col:startX, row:startY};
        let startKey=`${startX}x${startY}`;
        const q = [];
        const parentForCell = {};

        q.push(start);

        while(q.length>0){
            const {col, row} = q.shift();
            const curKey = `${col}x${row}`;
            const neighbors = [
                {col, row: row-1 },
                {col: col+1,row},
                {col, row: row+1},
                {col: col-1, row},
            ]
            for (let i = 0; i < neighbors.length; i++){
                const nRow = neighbors[i].row;
                const nCol = neighbors[i].col;

                if(nRow<0 || nRow > this.map.length-1){
                    continue;
                }
                if(nCol<0 || nCol > this.map[nRow].length-1){
                    continue;
                }
                if(this.ind.wall.includes(this.map[nRow][nCol])){
                    continue;
                }

                const key = `${nCol}x${nRow}`;

                if(key in parentForCell) {
                    continue;
                }
                parentForCell[key] = {
                    key: curKey,
                }
                q.push(neighbors[i]);
            }
        }

        const path = [];
        let currentKey = `${targetX}x${targetY}`;
        while(currentKey !== startKey){
            path.push(currentKey);
            const {key} = parentForCell[currentKey];
            currentKey = key;
        }

        // path.push(currentKey);
        path.reverse();
        return path;
    }

    update(obj) {
        if (obj.move_x === 0 && obj.move_y === 0)
            return "stop";
        let newX = obj.pos_x + Math.floor(obj.move_x * obj.speed);
        let newY = obj.pos_y + Math.floor(obj.move_y * obj.speed);
        let ts = mapManager.getTilesetIdx(newX + obj.size_x / 2, newY + obj.size_y / 2);

        let e = this.entityAtXY(obj, newX, newY);

        if (e !== null && obj.onTouchEntity)
            obj.onTouchEntity(e);

        if(ts !== 219 && obj.onTouchMap){
            obj.onTouchMap(ts);
        }
        if(ts === 219 && e === null){
            obj.pos_x = newX;
            obj.pos_y = newY;
            if(obj.name==='player' && (( Math.floor(obj.pos_x/128)!==this.player_x) || ( Math.floor(obj.pos_y/128)!==this.player_y))){
                let X = [Math.round(newX/128), Math.ceil(newX/128), Math.floor(newX/128)]
                let Y = [Math.round(newY/128), Math.ceil(newY/128), Math.floor(newY/128)]

                for(let y of Y){
                    for(let x of X){
                        if(!this.ind.wall.includes(this.map[y][x])){
                            this.player_x =  x;
                            this.player_y =  y;
                        }
                    }
                }
            }
        }else
            return "break";
        return "move";
    }

    entityAtXY(obj, x, y) {
        for (let i = 0; i < gameManager.entities.length; i++) {
            let e = gameManager.entities[i];

            if (e.name !== obj.name) {
                if (x + obj.size_x < e.pos_x ||
                    y + obj.size_y < e.pos_y ||
                    x > e.pos_x + e.size_x ||
                    y > e.pos_y + e.size_y)
                    continue;
                return e;
            }
        }
        return null;
    }
}