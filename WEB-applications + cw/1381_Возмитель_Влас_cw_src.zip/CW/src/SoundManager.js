export class SoundManager{
    constructor() {
        this.clips= {};
        this.context = null;
        this.gainNode = null;
        this.loaded = false;
        this.isPlaying = false
    }
    init() {
        this.context = new (window.AudioContext || window.webkitAudioContext)();
        this.gainNode = this.context.createGain();
        this.gainNode.connect(this.context.destination);

        this.context.resume().then(() => {
            this.loaded = true;
        });
    }
    load(path, callback){
        if(this.clips[path]){
            callback(this.clips[path]);
            return;
        }

        let clip={path:path, buffer:null, loaded:false};
        clip.play = (volume, loop)=>{
            this.play(this.path, {looping:loop?loop:false,
                volume:volume?volume:1});
        }

        this.clips[path] = clip;
        let request = new XMLHttpRequest();
        request.open("GET", path, true);
        request.responseType = 'arraybuffer';  // Corrected line
        request.onload = () => {
            this.context.decodeAudioData(
                request.response,
                buffer => {
                    clip.buffer = buffer;
                    clip.loaded = true;
                    callback(clip);
                },
                error => {
                    console.error('Error decoding audio data:', error);
                }
            );
        };
        request.send();
    }
    loadArray(array, callback) {
        let loadedClips = 0;

        array.forEach((path) => {
            if (this.clips[path]) {
                loadedClips++;

                if (loadedClips === array.length && callback) {
                    callback();
                }

                return;
            }

            let clip = { path: path, buffer: null, loaded: false };
            clip.play = (volume, loop) => {
                this.play(path, { looping: loop ? loop : false, volume: volume ? volume : 1 });
            };

            this.clips[path] = clip;

            let request = new XMLHttpRequest();
            request.open('GET', path, true);
            request.responseType = 'arraybuffer';

            request.onload = () => {
                this.context.decodeAudioData(
                    request.response,
                    (buffer) => {
                        clip.buffer = buffer;
                        clip.loaded = true;
                        loadedClips++;

                        if (loadedClips === array.length && callback) {
                            callback();
                        }
                    },
                    (error) => {
                        console.error('Error decoding audio data', error);
                    }
                );
            };
            this.isPlaying = true;


            request.send();
        });
    }
    play(path, settings){
        if(!this.loaded){
            setTimeout(()=>{
                this.play(path, settings);
            }, 1000);
            return;
        }

        let looping = false;
        let volume = 1;
        if(settings){
            if(settings.looping)
                looping = settings.looping;
            if(settings.volume)
                volume=settings.volume;
        }

        let sd = this.clips[path];
        if(sd===null)
            return false;

        let sound = this.context.createBufferSource();
        sound.buffer = sd.buffer;
        sound.connect(this.gainNode);
        sound.loop = looping;
        this.gainNode.gain.value = volume;
        sound.start(0);
        return true;
    }
    toggleMute(){
        const context = this.context;

        if (context.state === 'running') {
            context.suspend().then(() => {
                this.isPlaying = false;

            });
        } else if (context.state === 'suspended') {
            context.resume().then(() => {
                this.isPlaying = true;

            });
        }
    }
    stopAll(){
        this.gainNode.disconnect();
        this.gainNode = this.context.createGainNode(0);
        this.gainNode.connect(this.context.destination);
    }
}