import { MapManager } from "./MapManager.js"
import { SpriteManager } from "./Sprites.js"
import {GameManager} from "./GameManager.js";
import {EventsManager} from "./EventsManager.js";
import {PhysicManager} from "./PhysicManager.js";
import {SoundManager} from "./SoundManager.js"
import Score from "./recorder.js";
const loadMusic = () => {
    const musicPaths = ['../public/back.mp3', '../public/fire.mp3', '../public/bonus.mp3'
        ,'../public/end.mp3', '../public/start.mp3'];
    soundManager.loadArray(musicPaths, () => {
        if(soundManager.loaded)soundManager.play('../public/back.mp3', { volume: 0.2, looping: true });

    });
}
export let canvas = document.getElementById("canvasId");
export var ctx = canvas.getContext("2d");
canvas.width = 2560;
canvas.height = 2560;

export const mapManager = new MapManager()
export const spriteManager = new SpriteManager()
export const gameManager = new GameManager();
export const eventsManager = new EventsManager();
export const physicManager = new PhysicManager()
export const soundManager = new SoundManager();
export const recorder = new Score(localStorage['cw.user_name'], "", 0);


if(localStorage['cw.lvl'] === '1'){
    soundManager.init();
    loadMusic();
    gameManager.loadAll("./src/tilemap1.json", "1 map");
    gameManager.play();
}
else if(localStorage['cw.lvl'] === '2'){
    soundManager.init();
    loadMusic();
    gameManager.loadAll("./src/tilemap2.json", "2 map");
    gameManager.play();
}