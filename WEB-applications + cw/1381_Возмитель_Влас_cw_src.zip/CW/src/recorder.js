export default class Score {
    record = {
        place: 0,
        score: "",
        name: '',
        map: ""
    }
    constructor(name, score, place) {
        this.record.name = name;
        if (!this.record.name){
            this.record.name = 'Player';
        }
        this.record.score = score;
        this.record.place = place;
    }
    writeResults() {
        let score_table;
        if(localStorage['cw.lvl'] === "1")
            score_table = JSON.parse(localStorage.getItem('таблицаРекордов1')) || [];
        else
            score_table = JSON.parse(localStorage.getItem('таблицаРекордов2')) || [];

        score_table.push(this.record);
        score_table.sort((a, b) => {
            const timePartsA = a.score.split(':');
            const timePartsB = b.score.split(':');

            // в миллисекунды
            const timeInMillisecondsA =
                parseInt(timePartsA[1]) * 3600000 +
                parseInt(timePartsA[2]) * 60000 +
                parseInt(timePartsA[3]) * 1000 +
                parseInt(timePartsA[4])

            const timeInMillisecondsB =
                parseInt(timePartsB[1]) * 3600000 +
                parseInt(timePartsB[2]) * 60000 +
                parseInt(timePartsB[3]) * 1000 +
                parseInt(timePartsB[4])
            // Сравниваем значения времени в миллисекундах
            console.log(timePartsA, timePartsB)
            return timeInMillisecondsA - timeInMillisecondsB;
        });
        for(let i = 0; i < score_table.length; i++){
            score_table[i].place = i + 1;
        }
        if(localStorage['cw.lvl'] === "1")
            localStorage.setItem('таблицаРекордов1', JSON.stringify(score_table));
        else
            localStorage.setItem('таблицаРекордов2', JSON.stringify(score_table));
    }
}