import {SoundManager} from "./SoundManager.js"
export const soundManager = new SoundManager();

const loadMusic = () => {
    const musicPaths = ['../public/back.mp3', '../public/fire.mp3', '../public/bonus.mp3'
        ,'../public/end.mp3', '../public/start.mp3'];

    soundManager.loadArray(musicPaths, () => {});
}

document.getElementById("Enter").addEventListener("click", function() {
    soundManager.init();
    loadMusic();

    soundManager.play('../public/start.mp3', { volume: 0.2, looping: false });

});